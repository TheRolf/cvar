'''
Created on 25 Mar 2016

@author: Rolf
'''
from pulp.pulp import lpSum


class Objective(object):
    '''
    classdocs
    '''

    @staticmethod
    def add(problem, data):
        problem += problem.L_var + \
                    ( 1/((1-data.alpha)*data.numberOfHpfcCurves) ) * lpSum([problem.u_vars[s] for s in range(data.numberOfHpfcCurves)]), "Risk" 
        return problem