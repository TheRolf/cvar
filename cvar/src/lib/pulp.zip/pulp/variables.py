'''
Created on 25 Mar 2016

@author: Rolf
'''
from pulp.constants import LpContinuous
from pulp.pulp import LpVariable


class Variables(object):
    '''
    classdocs
    '''

    @staticmethod
    def add(problem, data):
        problem.x_vars = LpVariable.dicts('x', range(data.numberOfForwardProducts),
                                    lowBound = None,
                                    upBound = None,
                                    cat = LpContinuous)
        problem.u_vars = LpVariable.dict('u', range(data.numberOfHpfcCurves),
                                   lowBound = 0,
                                   upBound = None,
                                   cat = LpContinuous)
        problem.L_var = LpVariable('L', None, None, LpContinuous)
        return problem