'''
Created on 26 Mar 2016

@author: Rolf
'''
from pulp.constants import LpStatus

from lib.excel.excel_reader import ExcelReader
from lib.pulp.initialiser import Initialiser
from root import Root


class MainPulp(object):

    @staticmethod
    def main():
        #PROJECT_LOC = r"c:\\Users\\Rolf\\Desktop\\BME\\Workspace\\Diplomamunka\\cvar\\"
        data = ExcelReader(Root.path() + '/../resources/test1.xlsm')
        model = Initialiser(data)
        model.problem.solve()
        model.status = LpStatus(model.problem.status)
        print model.status
    
    
    if __name__ == '__main__':
        main()

    
    
    