'''
Created on 25 Mar 2016

@author: Rolf
'''
from pulp.constants import LpMinimize
from pulp.pulp import LpProblem

from lib.pulp.constraints.positive_part import PositivePart
from lib.pulp.objective import Objective
from lib.pulp.variables import Variables


class Initialiser(object):
    '''
    classdocs
    '''


    def __init__(self, data):
        self.problem = LpProblem("cVaR", LpMinimize)
        self.problem = Variables.add(self.problem, data)
        self.problem = Objective.add(self.problem, data)
        self.problem = PositivePart.add(self.problem, data)
        