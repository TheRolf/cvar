'''
Created on 25 Mar 2016

@author: Rolf
'''
from pulp.pulp import lpSum


class PositivePart(object):
    '''
    classdocs
    '''

    @staticmethod
    def add(problem, data):
        for s in range(data.numberOfHpfcCurves):
            problem +=  lpSum([ data.hpfcVectors[s][t] * (lpSum([data.forwardCharacteristicVectors[f][t]*problem.x_vars[f] for f in range(data.numberOfForwardProducts)])-data.demand[t]) for t in range(data.T+1, data.numberOfTimeIntervals) ]) + \
                        - lpSum([ (1+data.epsilon*problem.x_vars[f])*data.forwardPrices[f]*problem.x_vars[f] for f in range(data.numberOfForwardProducts) ]) + \
                        - problem.L_var + problem.u_vars[s], "Dummy constraint " + str(s)
        return problem